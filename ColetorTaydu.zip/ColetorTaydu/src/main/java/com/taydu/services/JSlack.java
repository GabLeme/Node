/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.taydu.services;

import com.github.seratch.jslack.Slack;
import com.github.seratch.jslack.api.webhook.Payload;
import com.github.seratch.jslack.api.webhook.WebhookResponse;
import java.io.IOException;

/**
 *
 * @author gabriel.leme
 */
public class JSlack {

    private final String url = "https://hooks.slack.com/services/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";

    public void enviaNotificacao(String texto) throws IOException {

        Payload payload = Payload.builder()
                .text(texto)
                .build();

        Slack slack = Slack.getInstance();
        try {
            WebhookResponse response = slack.send(url, payload);
        } catch (IOException ex) {
            System.out.println(ex);
        }
    }
}
