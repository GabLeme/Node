import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';


@Injectable({ providedIn: 'root' })
export class LoginService {

    constructor(private _http: HttpClient) { }

    tryLogin(email: string, password: string) {
        return this._http.get('http://ace.digisystem.com.br:3000/usuario/login/' + email + '/' + password);
    }
}


