import { Component, OnInit } from '@angular/core';
import { LoginService } from './login.service';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})

export class LoginComponent{


  constructor(private loginService: LoginService, private router: Router) { }

  loginForm = new FormGroup({
    username: new FormControl(),
    password: new FormControl()
  })


  get f() { return this.loginForm.controls; }

  onSubmit() {
    if (this.f.username.value == null || this.f.password.value == null) {
      document.getElementById('warning').innerHTML = "Os campos não podem ser vázios!";
      setTimeout(() => {
        document.getElementById('warning').innerHTML = "";
      }, 5000);
    }
    else {
      this.loginService.tryLogin(this.f.username.value, this.f.password.value).subscribe(
        response => {
          if (response == "") {
            document.getElementById('warning').innerHTML = "Usuário ou senha estão incorretos.";
            setTimeout(() => {
              document.getElementById('warning').innerHTML = "";
            }, 5000);
          }
          else {
            if (this.f.username.value == response[0]["EMAIL"] && this.f.password.value == response[0]["SENHA"]) {
              localStorage.setItem('cod_usuario', response[0]['COD_USUARIO']);
              localStorage.setItem('nome_usuario', response[0]['EMAIL']);
              this.router.navigate(['/machines']);
            }
          }
        }
      );
    }
  }
}


