import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { HttpHeaders } from '@angular/common/http';


@Injectable({ providedIn: 'root' })
export class UserRegisterService {

    constructor(private _http: HttpClient) { }


    registerUser(username, password) {
        const email = username;
        const senha = password;
        const user = JSON.stringify({
            "email": email,
            "senha": senha
        });
        const httpOptions = {
            headers: new HttpHeaders({
                'Content-Type': 'application/json',
            })
        };
        return this._http.post('http://ace.digisystem.com.br:3000/usuario/cadastro', user, httpOptions);
    }
}


