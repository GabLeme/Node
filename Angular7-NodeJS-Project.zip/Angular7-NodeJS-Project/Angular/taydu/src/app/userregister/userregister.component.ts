import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { UserRegisterService } from './userregister.service';
import { map } from 'rxjs/operators';


@Component({
  selector: 'app-userregister',
  templateUrl: './userregister.component.html',
  styleUrls: ['./userregister.component.css']
})
export class UserregisterComponent {

  constructor(private _UserRegisterService: UserRegisterService) { }


  userRegisterForm = new FormGroup({
    username: new FormControl(),
    password: new FormControl(),
    confirmPassword: new FormControl()
  })

  get f() { return this.userRegisterForm.controls; }

  verifyPassword(): boolean {
    if (this.f.confirmPassword.value == this.f.password.value) {
      return true;
    }
  }
  verifyFormValues(): boolean {
    if (this.f.username.value == null || this.f.password.value == null || this.f.confirmPassword.value == null) {
      return true;
    }
  }

  onSubmit() {
    console.log('oi')
    if (this.verifyFormValues()) {
      document.getElementById('warning').innerHTML = "Os campos não podem ser nulos";
      setTimeout(() => {
        document.getElementById('warning').innerHTML = "";
      }, 5000);
    }
    else {
      if (this.verifyPassword()) {
        this._UserRegisterService.registerUser(this.f.username.value, this.f.password.value).subscribe(
          r => {console.log(r)}
        );
        document.getElementById('warning').innerHTML = "Usuário cadastrado com sucesso!";
      }
      else {
        document.getElementById('warning').innerHTML = "As senhas não coincidem!";
        setTimeout(() => {
          document.getElementById('warning').innerHTML = "";
        }, 5000);
      }
    }
  }
}
