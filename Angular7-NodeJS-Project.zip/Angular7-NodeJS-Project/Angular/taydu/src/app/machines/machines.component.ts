import { Component, OnInit } from '@angular/core';
import { MachinesService } from './machines.service';
import { Router, ActivatedRoute } from '@angular/router';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';

@Component({
  selector: 'app-machines',
  templateUrl: './machines.component.html',
  styleUrls: ['./machines.component.css']
})
export class MachinesComponent implements OnInit {

  constructor(private _MachinesService: MachinesService, private _Router: Router) { }
  data: any;
  nomeUsuario;
  machineForm = new FormGroup({
    nomeMaquina: new FormControl(),
  })
  get f() { return this.machineForm.controls; }
  ngOnInit() {
    if(localStorage.getItem('cod_usuario') == null){
      location.href="/login";
    }
    if (localStorage.getItem('cod_usuario') != null || localStorage.getItem('cod_usuario') != "") {
      this._MachinesService.getMachines().subscribe(
        response => {
          this.data = response;
          var sample = JSON.stringify(response)
        }
      )
      this.nomeUsuario = localStorage.getItem('nome_usuario').toString();
    }
    else {
      this._Router.navigate(['/login']);
    }
  }

  logout() {
    localStorage.removeItem("cod_usuario");
    localStorage.removeItem("cod_maquina");
    location.href="/login";
  }

  setCodMaquina(selectedItem: any) {
    window.localStorage.setItem('cod_maquina', selectedItem.COD_MAQUINA);
    location.href="/dashboard"
  }

  deleteMaquina(selectedItem: any) {
    this._MachinesService.deleteReads(selectedItem.COD_MAQUINA).subscribe(
      r => { console.log(r) }
    );
    setTimeout(() => {
      this._MachinesService.deleteMachine(selectedItem.COD_MAQUINA).subscribe(
        r => { console.log(r) }
      );
    }, 3000);
    setTimeout(() => {
      window.location.reload();
    }, 5000);
  }

  cadastrarMaquina(){
    let cod = this.getRandom();
    this._MachinesService.registerMachine(cod, this.f.nomeMaquina.value, parseInt(localStorage.getItem('cod_usuario')), 'OFF')
    .subscribe(r => {console.log(r)});
  }

  onSubmit(){
    this.cadastrarMaquina();
    document.getElementById('loading').innerHTML = "Cadastrando.."
    setTimeout(() => {
      window.location.reload();
    }, 5000);
  }

  getRandom(){
    return Math.floor(Math.random() * 10000 + 1);
  }


}
