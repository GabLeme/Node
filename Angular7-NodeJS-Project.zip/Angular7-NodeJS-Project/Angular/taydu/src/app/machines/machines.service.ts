import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { HttpHeaders } from '@angular/common/http';
import {Observable,of, from } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class MachinesService {

    constructor(private _http: HttpClient) { }

    cod_usuario = parseInt(localStorage.getItem('cod_usuario'));

    getMachines() {
        return this._http.get('http://ace.digisystem.com.br:3000/usuario/maquina/' + this.cod_usuario);
    }

    deleteReads(cod_maquina) {
        return this._http.delete('http://ace.digisystem.com.br:3000/usuario/maquina/leitura/' + cod_maquina)
    }

    deleteMachine(cod_maquina) {
        return this._http.delete('http://ace.digisystem.com.br:3000/usuario/maquina/' + cod_maquina);
    }

    registerMachine(cod_maquina, nome_maquina, cod_usuario, status) {
        const codmaquina = cod_maquina;
        const nomemaquina = nome_maquina;
        const codusuario = cod_usuario;
        const ativa = status;
        const machine = JSON.stringify({
            "codMaquina": codmaquina,
            "nomeMaquina": nomemaquina,
            "codUsuario": codusuario,
            "ativa": ativa
        });
        const httpOptions = {
            headers: new HttpHeaders({
                'Content-Type': 'application/json',
                'Access-Control-Allow-Headers': 'Origin, Accept, X-Requested-With, Content-Type, Access-Control-Request-Method, Access-Control-Request-Headers'
            })
        };
        return this._http.post('http://ace.digisystem.com.br:3000/usuario/cadastro/maquina', machine, httpOptions);
    }

    notificaSlack(): Observable<any> {
        const notificacao = JSON.stringify({
            "text": "texto"
        });
        const httpOptions = {
            headers: new HttpHeaders({
                'Content-Type': 'application/json',
            })
        };
        return this._http.post('https://hooks.slack.com/services/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', notificacao, httpOptions);

    }

    //Criar Método para notificar exclusão ou que adicionou máquinas
}


