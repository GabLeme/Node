import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { MachinesComponent } from './machines/machines.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { UserregisterComponent } from './userregister/userregister.component';
const routes: Routes = [
  { path: 'login', component: LoginComponent },
  { path: 'machines', component: MachinesComponent},
  { path: 'dashboard', component: DashboardComponent},
  { path: 'register', component: UserregisterComponent},
];

@NgModule({
  exports: [ RouterModule ],
  imports: [ RouterModule.forRoot(routes) ],
})

export class AppRoutingModule { }

