import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { HttpHeaders } from '@angular/common/http';
import { timer, of } from 'rxjs';
import { switchMap, catchError } from 'rxjs/operators';

@Injectable({ providedIn: 'root' })
export class AlertsService {

    constructor(private _http: HttpClient) { }

    id_maquina = localStorage.getItem('cod_maquina');

    // registerAlert(descricao) {
    //     const id_maquina = this.id_maquina;
    //     const alerta = JSON.stringify({
    //         "descricao": descricao
    //     });
    //     const httpOptions = {
    //         headers: new HttpHeaders({
    //             'Content-Type': 'application/json',
    //         })
    //     };
    //     return this._http.post('http://localhost:3000/usuario/cadastro/alerta', alerta, httpOptions)

    // }
}


