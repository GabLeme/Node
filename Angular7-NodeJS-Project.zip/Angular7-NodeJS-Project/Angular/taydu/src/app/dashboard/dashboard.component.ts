import { Component, OnInit } from '@angular/core';
import { ReadingsService } from './readings.service';
import { Chart } from 'chart.js';
import * as $ from 'jquery';
import { AlertsService } from './alerts.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {

  constructor(private _ReadingsService: ReadingsService, private _AlertsService: AlertsService) { }
  chartRam: Chart = [];
  chartCpu: Chart = [];
  chartHdPerc: Chart = [];
  chartHd: Chart = [];
  percentualMemoriaRam = [];
  percentualCpu = [];
  percentualAtividadeHd = [];
  percentualHd = [];
  horaLeitura = [];
  alertas = [];

  ultimaLeituraRam: any;
  ultimaLeituraCpu: any;
  ultimaLeituraHdP: any;
  ultimaLeituraHdA: any;

  logout() {
    localStorage.removeItem("cod_usuario");
    localStorage.removeItem("cod_maquina");
    location.href = "/login";
  }

  dataRam: any = [];
  dataCpu: any = [];
  dataHdA: any = [];
  dataHdP: any = [];


  ngOnInit() {
    if (localStorage.getItem('cod_maquina') == null || localStorage.getItem('cod_maquina') == "") {
      location.href = "/login";
    }
    else {
      this._ReadingsService.getAnalyticsRam().subscribe(
        response => {
          this.dataRam = response;
          let sample = JSON.stringify(response)
          console.log(sample);

        }
      )
      this._ReadingsService.getAnalyticsCpu().subscribe(
        response => {
          this.dataCpu = response;
          let sample = JSON.stringify(response)
        }
      )
      this._ReadingsService.getAnalyticsHdAtividade().subscribe(
        response => {
          this.dataHdA = response;
          let sample = JSON.stringify(response)
        }
      )
      this._ReadingsService.getAnalyticsHdPercentual().subscribe(
        response => {
          this.dataHdP = response;
          let sample = JSON.stringify(response)
        }
      )
      this._ReadingsService.getReadings().subscribe(r => {
        var gabiData = r[0]["HORA_LEITURA"];
        var gabiDataSeparada = gabiData.split("T");
        var gabiSeraQvai = gabiDataSeparada[1].split(".");
        var splitandoTudo = gabiSeraQvai[0].split(":");
        var exibeDataFormatada = `${splitandoTudo[0]}:${splitandoTudo[1]}`;
        this.ultimaLeituraRam = r[0]["RAM_PERCENTUAL"];
        this.ultimaLeituraCpu = r[0]["CPU_PERCENTUAL"];
        this.ultimaLeituraHdP = r[0]["HD_PERCENTUAL"];
        this.ultimaLeituraHdA = r[0]["HD_TEMPO_ATIVIDADE_PERCENTUAL"];
        this.percentualMemoriaRam.push(r[0]["RAM_PERCENTUAL"]);
        this.percentualCpu.push(r[0]["CPU_PERCENTUAL"]);
        this.percentualAtividadeHd.push(r[0]["HD_TEMPO_ATIVIDADE_PERCENTUAL"]);
        this.percentualHd.push(r[0]["HD_PERCENTUAL"]);
        this.horaLeitura.push(exibeDataFormatada);

        // if(parseInt(r[0]["RAM_PERCENTUAL"]) >  75){
        //   this._AlertsService.registerAlert("Sua memória RAM está acima de 75%, hora do aviso: " + this.horaLeitura[0] + ".").subscribe(r=>{console.log(r)});
        //   console.log("enviou")
        // }

        this.chartRam = new Chart('canvasRam', {
          type: 'line',
          data: {
            labels: this.horaLeitura,
            datasets: [
              {
                label: 'Percentual Memória Ram',
                data: this.percentualMemoriaRam,
                borderColor: '#8300b7',
                fill: false,
                backgroundColor: '#8300b7'
              }
            ]
          },
          options: {
            title: {
              display: true,
              text: 'Memória Ram'
            },
            animation: {
              duration: 0
            }
          },
        });
        this.chartCpu = new Chart('canvasCpu', {
          type: 'line',
          data: {
            labels: this.horaLeitura,
            datasets: [
              {
                label: 'Percentual Processador',
                data: this.percentualCpu,
                borderColor: '#02a4fc',
                fill: false,
                backgroundColor: '#02a4fc'
              }
            ]
          },
          options: {
            title: {
              display: true,
              text: 'Processador'
            },
            animation: {
              duration: 0
            }
          },
        });
        this.chartHdPerc = new Chart('canvasPercHd', {
          type: 'line',
          data: {
            labels: this.horaLeitura,
            datasets: [
              {
                label: 'Percentual Atividade Hd',
                data: this.percentualAtividadeHd,
                borderColor: '#01ad43',
                fill: false,
                backgroundColor: '#01ad43'
              }
            ]
          },
          options: {
            title: {
              display: true,
              text: 'Atividade Hd'
            },
            animation: {
              duration: 0
            }
          },
        });
        this.chartHd = new Chart('canvasHd', {
          type: 'line',
          data: {
            labels: this.horaLeitura,
            datasets: [
              {
                label: 'Percentual de Uso Hd',
                data: this.percentualHd,
                borderColor: '#ad5f01',
                fill: false,
                backgroundColor: '#ad5f01'
              }
            ]
          },
          options: {
            title: {
              display: true,
              text: 'Atividade Hd'
            },
            animation: {
              duration: 0
            }
          },
        });

        this.percentualMemoriaRam.forEach(data => {
          //Máximo de 60 itens exibidos no gráfico
          if (this.chartRam.data.labels.length == 10 && this.chartRam.data.datasets[0].data.length == 10) {
            this.chartRam.data.labels.shift();
            this.chartRam.data.datasets[0].data.shift();

          }
          if (this.chartCpu.data.labels.length == 10 && this.chartCpu.data.datasets[0].data.length == 10) {
            this.chartCpu.data.labels.shift();
            this.chartCpu.data.datasets[0].data.shift();

          }
          if (this.chartHdPerc.data.labels.length == 10 && this.chartHdPerc.data.datasets[0].data.length == 10) {
            this.chartHdPerc.data.labels.shift();
            this.chartHdPerc.data.datasets[0].data.shift();

          }
          if (this.chartHd.data.labels.length == 10 && this.chartHd.data.datasets[0].data.length == 10) {
            this.chartHd.data.labels.shift();
            this.chartHd.data.datasets[0].data.shift();

          }
          // this.chartCpu.defaults.global.responsive = true;
          // this.chartHdPerc.defaults.global.responsive = true;
          // this.chartHd.defaults.global.responsive = true;
          // this.chartRam.defaults.global.responsive = true;
          this.chartRam.update();

          this.chartCpu.update();
          this.chartHdPerc.update();
          this.chartHd.update();

        });
      });
    }
  }

  enviarMensagem() {

    var ultimaLeituraCpu = this.ultimaLeituraCpu;
    var ultimaLeituraHdA = this.ultimaLeituraHdA;
    var ultimaLeituraRam = this.ultimaLeituraRam;
    var ultimaLeituraHdP = this.ultimaLeituraHdP;
    var horaLeitura = this.horaLeitura;
    console.log(ultimaLeituraRam)
    var a = parseInt(localStorage.getItem('cod_maquina'));
    console.log(a);
    if ($("#mensagem #texto").val() === "") {
      $("#chat").append("<div class=\"texto chatbot\">...</div>");
      $(".mensagens").animate({ scrollTop: $("#chat").height() });
      setTimeout(function () {
        //Adiciona uma resposta padrão afirmando que o usuário deixou o campo vazio
        $("#chat").append("<div class=\"texto usuario\">Você precisa digitar alguma coisa para prosseguir.</div>");
        $(".mensagens").animate({ scrollTop: $("#chat").height() });
      }, 1000);
      return false;
    }

    var inputUsuario = $('#texto').val();

    var dadosEnviados = JSON.stringify({
      "input": {
        "text": inputUsuario
      }
    });

    //Inicia método AJAX
    $.ajax({
      type: 'POST',
      url: "https://gateway.watsonplatform.net/assistant/api/v1/workspaces/1c2e3ccf-5fd0-485d-b6c4-0f7da1af7eb9/message?version=2018-11-26",
      dataType: 'json', // Determina o tipo de retorno
      contentType: 'application/json',
      data: dadosEnviados,
      beforeSend: function (xhr) {
        xhr.setRequestHeader("Authorization", "Basic " + btoa("apikey" + ":" + "U92PhngxUW43WhOMt2fea4X6kDA-en4pgMmPXkHwwbTA"));
        $("#chat").append("<div class=\"texto chatbot\">" + $("#mensagem #texto").val() + "</div>");
      },
      success: function (resposta) {
        if (resposta.input.text.includes("leitura")) {
          resposta.output.text[0] = "Suas ultimas leituras são: Cpu: " + ultimaLeituraCpu + "%, Ram: " + ultimaLeituraRam + "%, Porcentagem de uso HD: " + ultimaLeituraHdP + "%, Atividade de Disco: " + ultimaLeituraHdA + "%, Hora da leitura: " + horaLeitura[0] + ".";
        }
        $("#mensagem #texto").val("");
        $("#mensagem #texto").focus();

        if (resposta.error) {
          $("#chat").append("<div class=\"texto usuario\">" + resposta.error + "</div>");
          return false;
        }

        var mensagemChatbot = "<div class=\"texto usuario\">";
        mensagemChatbot += resposta.output.text[0];
        mensagemChatbot += "</div>";
        setTimeout(function () {
          $("#chat").append(mensagemChatbot);
          $(".mensagens").animate({ scrollTop: $("#chat").height() });
        }, 1000);
        console.log(mensagemChatbot);
      },
      error: function (error) {
        console.log(error);
      }
    });

    return false;

  };

}





