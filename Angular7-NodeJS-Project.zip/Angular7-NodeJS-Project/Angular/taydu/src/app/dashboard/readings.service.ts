import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { timer, of } from 'rxjs';
import { switchMap, catchError } from 'rxjs/operators';

@Injectable({ providedIn: 'root' })
export class ReadingsService {

    constructor(private _http: HttpClient) { }

    cod_maquina = parseInt(localStorage.getItem('cod_maquina'));

    getReadings() {
        return timer(0, 10000)
            .pipe(
                switchMap(_ => this._http.get('http://ace.digisystem.com.br:3000/usuario/maquina/leitura/' + this.cod_maquina)),
                catchError(error => of(`Bad request: ${error}`))
            );
    }

    getAnalyticsRam() {
        return timer(0, 15000)
            .pipe(
                switchMap(_ => this._http.get('http://ace.digisystem.com.br:3000/usuario/maquina/analytics/ram/' + this.cod_maquina)),
                catchError(error => of(`Bad request: ${error}`))
            );
    }

    getAnalyticsCpu() {
        return timer(0, 15000)
            .pipe(
                switchMap(_ => this._http.get('http://ace.digisystem.com.br:3000/usuario/maquina/analytics/cpu/' + this.cod_maquina)),
                catchError(error => of(`Bad request: ${error}`))
            );
    }

    getAnalyticsHdPercentual() {
        return timer(0, 15000)
            .pipe(
                switchMap(_ => this._http.get('http://ace.digisystem.com.br:3000/usuario/maquina/analytics/hd/percentual/' + this.cod_maquina)),
                catchError(error => of(`Bad request: ${error}`))
            );
    }

    getAnalyticsHdAtividade() {
        return timer(0, 15000)
            .pipe(
                switchMap(_ => this._http.get('http://ace.digisystem.com.br:3000/usuario/maquina/analytics/hd/atividade/' + this.cod_maquina)),
                catchError(error => of(`Bad request: ${error}`))
            );
    }

}


