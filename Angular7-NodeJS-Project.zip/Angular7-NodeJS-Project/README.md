# Angular7-NodeJS-Project
Projeto acadêmico de monitoramento de Hardware utilizando Javascript + Typescript.
